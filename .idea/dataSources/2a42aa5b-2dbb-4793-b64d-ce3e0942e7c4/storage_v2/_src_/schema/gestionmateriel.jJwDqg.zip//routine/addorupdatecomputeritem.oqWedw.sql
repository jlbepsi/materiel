create procedure addOrUpdateComputerItem(IN computerId int, IN itemId int, IN qty int)
  BEGIN
    DECLARE qtyStock INT;

    IF (EXISTS( SELECT * FROM computeritem
                WHERE computer_id = computerId
                  AND item_id = itemId)) THEN
    BEGIN
      UPDATE computeritem SET quantity = quantity + qty
      WHERE computer_id = computerId  AND item_id = itemId;
    END;
    ELSE
    BEGIN
      INSERT INTO computeritem VALUES (computer_id, item_id, quantity);
    END;
    END IF;

  END;

