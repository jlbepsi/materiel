create trigger item_onchange
  before INSERT
  on component
  for each row
  BEGIN

    IF NEW.quantitystock < 0 THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La quantité en stock doit être suprérieure à 0';
  END IF;
END;

